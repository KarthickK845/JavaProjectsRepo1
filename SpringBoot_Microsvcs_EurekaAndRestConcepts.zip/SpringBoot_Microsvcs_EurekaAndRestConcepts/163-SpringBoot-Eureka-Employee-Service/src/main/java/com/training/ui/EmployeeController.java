package com.training.ui;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.model.Employee;

@RestController
public class EmployeeController {

	@GetMapping("/employees")
	public ResponseEntity<List> f1(){
		Employee e1 = new Employee(101, "Mala", 30000.00);
		Employee e2 = new Employee(102, "Mahesh", 25000.00);
		Employee e3 = new Employee(103, "Ramesh", 15000.00);
		
		List<Employee> employees = new ArrayList<>();
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		
		return ResponseEntity.ok(employees);
	}
}
