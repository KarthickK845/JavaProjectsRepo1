package com.training.model;

public class CarLoanImpl extends LoanImpl{
	private String regNo;

	public CarLoanImpl(double loanAmt, int tenure, String regNo) {
		super(loanAmt, tenure);
		this.regNo = regNo;
	}

	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	@Override
	public double getInterestRate() {
		return 0.25;
	}

	@Override
	public void printDetails() {
		System.out.println("Car Registration Number : "+ this.getRegNo());
		System.out.println("Loan Amount : "+this.getLoanAmt());
		System.out.println("Tenure : "+this.getTenure());
		
	}
	
	
}
