package com.training.model;

public interface Loan {
	 double getInterestRate();
	 
	 void printDetails();
}
