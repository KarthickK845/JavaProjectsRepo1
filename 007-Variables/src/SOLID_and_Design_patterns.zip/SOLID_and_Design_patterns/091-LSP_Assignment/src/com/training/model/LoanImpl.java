package com.training.model;

public abstract class LoanImpl implements Loan{
	double loanAmt;
	int tenure;
	
	public LoanImpl(double loanAmt, int tenure) {
		super();
		this.loanAmt = loanAmt;
		this.tenure = tenure;
	}

	public double getLoanAmt() {
		return loanAmt;
	}

	public void setLoanAmt(double loanAmt) {
		this.loanAmt = loanAmt;
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	
	public abstract double getInterestRate();
	
	public abstract void printDetails();
}
