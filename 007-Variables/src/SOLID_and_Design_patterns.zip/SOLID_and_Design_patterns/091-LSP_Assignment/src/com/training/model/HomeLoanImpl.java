package com.training.model;

public class HomeLoanImpl extends LoanImpl{
	
	private String propertyLocation;	

	public HomeLoanImpl(double loanAmt, int tenure, String propertyLocation) {
		super(loanAmt, tenure);
		this.propertyLocation = propertyLocation;
	}

	public String getPropertyLocation() {
		return propertyLocation;
	}

	public void setPropertyLocation(String propertyLocation) {
		this.propertyLocation = propertyLocation;
	}
	
	public double getInterestRate() {
		return 0.15;
	}

	@Override
	public void printDetails() {
		System.out.println("Home Property Location : "+ this.getPropertyLocation());
		System.out.println("Loan Amount : "+this.getLoanAmt());
		System.out.println("Tenure : "+this.getTenure());
		
	}
}
