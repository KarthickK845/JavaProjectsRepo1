package com.training.ui;

import com.training.model.CarLoanImpl;
import com.training.model.HomeLoanImpl;
import com.training.model.Loan;

public class Main1 {

	public static void main(String[] args) {
		Loan loan = new CarLoanImpl(500000.00, 5, "KA 05 B1234");
		loan.printDetails();
		System.out.println("Interest Rate : " + loan.getInterestRate());

		System.out.println("---------------------------");
		loan = new HomeLoanImpl(200000.0, 10, "Bangalore");
		loan.printDetails();
		System.out.println("Interest Rate : " + loan.getInterestRate());
	}

}
