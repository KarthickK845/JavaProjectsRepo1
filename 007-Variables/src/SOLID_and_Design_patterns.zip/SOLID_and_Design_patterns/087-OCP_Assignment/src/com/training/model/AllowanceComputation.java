package com.training.model;

public class AllowanceComputation {
	public double computeAllowance(Allowance allowance, double basicSalary) {
		double result = 0.0;
		result = allowance.calculate(basicSalary);
		return result;
		
//		double allowance = 0.0;
//		if(grade == 'A')
//			allowance = 0.35*basicSalary;
//		if(grade == 'B')
//			allowance = 0.25*basicSalary;
//		if(grade == 'C')
//			allowance = 0.15*basicSalary;
		//if new grades are introduced in future, we may have to modify this code which is not encouraged
		//so we create subclasses for each conditions
//		return allowance;
	}
}
