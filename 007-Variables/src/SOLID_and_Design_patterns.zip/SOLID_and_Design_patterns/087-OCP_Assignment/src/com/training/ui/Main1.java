package com.training.ui;

import com.training.model.AGradeAllowance;
import com.training.model.AllowanceComputation;
import com.training.model.BGradeAllowance;
import com.training.model.CGradeAllowance;

public class Main1 {

	public static void main(String[] args) {
		AllowanceComputation allowanceComputation = new AllowanceComputation();
		double allowanceForAGrade = allowanceComputation.computeAllowance(new AGradeAllowance(), 12000.00);
		double allowanceForBGrade = allowanceComputation.computeAllowance(new BGradeAllowance(), 12000.00);
		double allowanceForCGrade = allowanceComputation.computeAllowance(new CGradeAllowance(), 12000.00);
		
		System.out.println("Allowance For A Grade : " + allowanceForAGrade);
		System.out.println("Allowance For B Grade : " + allowanceForBGrade);
		System.out.println("Allowance For C Grade : " +allowanceForCGrade);
	}

}
