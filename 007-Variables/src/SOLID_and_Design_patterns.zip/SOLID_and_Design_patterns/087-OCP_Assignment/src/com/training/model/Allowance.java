package com.training.model;

public interface Allowance {
	double calculate(double basicSalary);
}
