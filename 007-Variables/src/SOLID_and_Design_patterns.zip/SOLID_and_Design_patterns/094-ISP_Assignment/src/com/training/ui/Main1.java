package com.training.ui;

import com.training.model.Book;
import com.training.model.PDFBook;
import com.training.model.SimpleBook;

public class Main1 {
	public static void main(String[] args) {
		Book book = new SimpleBook();
		book.readBook();
		
		PDFBook pdfBook = new PDFBook();
		pdfBook.readBook();
		pdfBook.printBook();
		pdfBook.emailBook();
	}
}
