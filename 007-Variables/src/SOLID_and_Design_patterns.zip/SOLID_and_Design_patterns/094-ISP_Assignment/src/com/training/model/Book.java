package com.training.model;

public interface Book {
	void readBook();
}
