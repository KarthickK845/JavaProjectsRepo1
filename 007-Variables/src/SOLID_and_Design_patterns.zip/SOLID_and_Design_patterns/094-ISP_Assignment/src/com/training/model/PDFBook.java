package com.training.model;

public class PDFBook implements Book, PrintableBook, ShareableBook{
	
	
	@Override
	public void emailBook() {
		System.out.println("Mailing the PDF Book");
	}

	@Override
	public void printBook() {
		System.out.println("Printing the PDF Book");
	}

	@Override
	public void readBook() {
		System.out.println("Reading the PDF Book");
	}
}
