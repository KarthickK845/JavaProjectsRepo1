package com.training.model;

public class SimpleBook implements Book{

	@Override
	public void readBook() {
		System.out.println("Reading the Simple Book");
	}
	
}
