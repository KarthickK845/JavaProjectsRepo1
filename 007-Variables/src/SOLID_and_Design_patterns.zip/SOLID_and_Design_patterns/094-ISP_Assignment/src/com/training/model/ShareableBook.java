package com.training.model;

public interface ShareableBook {
	void emailBook();
}
