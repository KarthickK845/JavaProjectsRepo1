package com.training.model;

public interface PrintableBook {
	void printBook();
}
