package com.training.model;

public class TaxCalculator {
	public double computeTax(Employee employee) {
		double tax = 0;
		char grade = employee.getGrade();
		double basic = employee.getBasicSalary();
		if(grade == 'A')
			tax = basic*0.28;
		if(grade == 'B')
			tax = basic*0.20;
		if(grade == 'C')
			tax = basic*0.10;
		return tax;
	}
}
