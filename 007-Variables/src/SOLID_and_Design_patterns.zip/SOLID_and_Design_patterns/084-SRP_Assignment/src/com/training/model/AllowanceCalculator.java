package com.training.model;

public class AllowanceCalculator {
	public double computeAllowance(Employee employee) {
		double allowance = 0;
		char grade = employee.getGrade();
		double basic = employee.getBasicSalary();
		if(grade == 'A')
			allowance = basic*0.35;
		if(grade == 'B')
			allowance = basic*0.25;
		if(grade == 'C')
			allowance = basic*0.20;
		return allowance;
	}
}
