package com.training.ui;

import com.training.model.AllowanceCalculator;
import com.training.model.Employee;
import com.training.model.NetSalaryCalculator;
import com.training.model.TaxCalculator;

public class Main {
	public static void main(String[] args) {
		Employee employee  = new Employee(122, "Sooriya", 14000.00, 'B');
		
		AllowanceCalculator allowanceCalculator = new AllowanceCalculator();
		double allowance = allowanceCalculator.computeAllowance(employee);
		
		TaxCalculator taxCalculator = new TaxCalculator();
		double tax = taxCalculator.computeTax(employee);
		
		NetSalaryCalculator netSalaryCalculator = new NetSalaryCalculator();
		double netSalary = netSalaryCalculator.getNetSalary(employee, allowanceCalculator, taxCalculator);
		
		System.out.println(employee);
		System.out.println("------------------------------------");
		System.out.println("Employee Allowance : "+ allowance);
		System.out.println("Employee Tax : "+ tax);
		System.out.println("Employee Net Salary : "+ netSalary);
		
	}
}
