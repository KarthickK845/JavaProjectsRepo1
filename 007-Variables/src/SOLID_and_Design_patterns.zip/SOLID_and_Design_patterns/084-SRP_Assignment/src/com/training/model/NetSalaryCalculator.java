package com.training.model;

public class NetSalaryCalculator {
	public double getNetSalary(Employee employee, AllowanceCalculator allowCal, TaxCalculator taxCal) {
		return employee.getBasicSalary() + allowCal.computeAllowance(employee) - taxCal.computeTax(employee);
	}
}
