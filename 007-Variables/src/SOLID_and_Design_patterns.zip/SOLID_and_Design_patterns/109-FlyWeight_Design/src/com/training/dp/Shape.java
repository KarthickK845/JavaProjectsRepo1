package com.training.dp;

public interface Shape {
	void draw();
}
