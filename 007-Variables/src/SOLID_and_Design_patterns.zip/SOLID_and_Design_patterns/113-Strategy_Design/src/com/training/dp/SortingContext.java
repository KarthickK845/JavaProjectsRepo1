package com.training.dp;

public class SortingContext {
	SortingStrategy strategy;

	public SortingContext(SortingStrategy strategy) {
		super();
		this.strategy = strategy;
	}

	public void setStrategy(SortingStrategy strategy) {
		this.strategy = strategy;
	}
	
	public void performSort(int[] array) {
		strategy.sort(array);
	}
}
