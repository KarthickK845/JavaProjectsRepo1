package com.training.dp;

public interface SortingStrategy {
	void sort(int[] array);
}
