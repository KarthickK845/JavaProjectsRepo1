package com.training.model;

public interface Deduction {
	double computeDeduction(double basicSalary);
}
