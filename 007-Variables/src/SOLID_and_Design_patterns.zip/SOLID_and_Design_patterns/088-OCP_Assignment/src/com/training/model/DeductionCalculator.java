package com.training.model;

public class DeductionCalculator {
	public double computeDeduction(Deduction deduction, double basicSalary) {
		double result = 0.0;
		result = deduction.computeDeduction(basicSalary);
		return result;
	}
}
