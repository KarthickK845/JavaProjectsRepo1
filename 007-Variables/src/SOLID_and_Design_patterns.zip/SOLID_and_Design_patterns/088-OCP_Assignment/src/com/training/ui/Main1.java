package com.training.ui;

import com.training.model.AGradeDeduction;
import com.training.model.BGradeDeduction;
import com.training.model.CGradeDeduction;
import com.training.model.DeductionCalculator;

public class Main1 {

	public static void main(String[] args) {
		
		DeductionCalculator deductionCalculator = new DeductionCalculator();
		double deductionForAGrade = deductionCalculator.computeDeduction(new AGradeDeduction(), 10000.00);
		double deductionForBGrade = deductionCalculator.computeDeduction(new BGradeDeduction(), 10000.00);
		double deductionForCGrade = deductionCalculator.computeDeduction(new CGradeDeduction(), 10000.00);
		
		System.out.println("Deduction For A Grade : " + deductionForAGrade);
		System.out.println("Deduction For B Grade : " + deductionForBGrade);
		System.out.println("Deduction For C Grade : " +deductionForCGrade);
	}

}
