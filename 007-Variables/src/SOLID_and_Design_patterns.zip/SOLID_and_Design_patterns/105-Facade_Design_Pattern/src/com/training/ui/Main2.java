package com.training.ui;

import com.training.dp.BookingFacade;
import com.training.dp.User;

public class Main2 {
	public static void main(String[] args) {
		User user = new User("Shaheer","shaheer@gmail.com","9876578859");
		
		BookingFacade bookingFacade = new BookingFacade();
		bookingFacade.createBooking(user);
	}
}
