package com.training.dp;

public class TicketSystem {
	public boolean validateAvailability(String movie) {
		return true;
	}
	
	public void createTicket(int ticketno, User user, String movie) {
		System.out.println("Ticket Creation...");
	}
	
	public int getTicketNumber() {
		return 101;
	}
}
