package com.training.dp;

public class PaymentSystem {
	public void chargeCard() {
		System.out.println("Payment System Charging...");
	}
}
