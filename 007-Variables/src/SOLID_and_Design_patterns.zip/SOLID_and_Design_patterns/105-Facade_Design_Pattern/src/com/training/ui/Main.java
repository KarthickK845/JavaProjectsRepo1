package com.training.ui;

import javax.swing.text.ParagraphView;

import com.training.dp.NotificationSystem;
import com.training.dp.PaymentSystem;
import com.training.dp.TicketSystem;
import com.training.dp.User;

public class Main {
	//we are using different classes for one purpose - Ticket Booking
	//having complex code in main making client work with all these systems
	
	//instead we create a method inside another class 
	//and write all the complex code inside that method
	
	//in a facade - outlook
	//only face of the house is shown, high level is shown
	//inside we take care of all the low level functions
	
	public static void main(String[] args) {
		User user = new User("Shaheer","shaheer@gmail.com","9876578859");
		
		TicketSystem ts = new TicketSystem();
		
		boolean isBookingAvailable = ts.validateAvailability("movie");
		
		if(isBookingAvailable) {
			ts.createTicket(101, user, "movie");
			
			PaymentSystem ps = new PaymentSystem();
			ps.chargeCard();
			
			NotificationSystem ns = new NotificationSystem();
			ns.sendEmail(user, ts.getTicketNumber());
			ns.sendSMS(user, ts.getTicketNumber());
					
		}
	}
}
