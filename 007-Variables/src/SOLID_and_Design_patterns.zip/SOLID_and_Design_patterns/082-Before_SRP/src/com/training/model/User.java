package com.training.model;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class User {
	//purpose/responsibility of this class is to hold below info and also 3 more responsibilities (methods)
	//but for easy maintenance
	private String name;
	private String emailId;
	private String phoneNumber;
	public User(String name, String emailid, String phoneNumber) {
		super();
		this.name = name;
		this.emailId = emailid;
		this.phoneNumber = phoneNumber;
	}
	public User() {
		super();
	}
	
	public void sendEmail() {
		System.out.println("Sending Email to "+emailId);
	}
	
	public void sendSMS() {
		System.out.println("Sending SMS to "+phoneNumber);
	}
	
	public void saveUser() {
		OutputStream os;
		try {
			os = new FileOutputStream(name+".txt");
			Writer writer = new OutputStreamWriter(os);
			writer.write("Name : "+this.name +"\n");
			writer.write("Email : "+this.emailId+"\n");
			writer.write("Contact Number : "+this.phoneNumber);
			
			writer.flush();
			writer.close();
			os.close();
		} catch (Exception e) {
			System.err.println(e);
		}
		
	}
}
