package com.training.ui;

import com.training.model.User;

public class Main1 {

	public static void main(String[] args) {
		User user = new User("Mamta", "mamta@gmail.com", "9876759221");
		user.saveUser();
		user.sendSMS();
		user.sendEmail();

	}

}
