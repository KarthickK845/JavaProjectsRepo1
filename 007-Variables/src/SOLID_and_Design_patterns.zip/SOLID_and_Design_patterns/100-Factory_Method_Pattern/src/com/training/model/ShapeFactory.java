package com.training.model;

public class ShapeFactory {
	//core purpose of factory is to create object here instead of main
	int type;
	int size; 
	
	
	
	public ShapeFactory(int type, int size) {
		super();
		this.type = type;
		this.size = size;
	}



	//Factory Method
	
	// this can be static as well
	public Shape createShape() {
		Shape shape = null;
		if(type == 1)
			shape = new CircleImpl();
		if(type == 2)
			shape = new Square();
		if(type == 3)
			shape = new RectangleImpl();
		
		shape.setSize(size); //factory method creates object and sets the size as well
		
		return shape;
	}
}
