package com.training.ui;

import com.training.model.Shape;
import com.training.model.ShapeFactory;

public class Main {

	public static void main(String[] args) {
//		Circle circle = new Circle(10);
//		System.out.println(circle.getRadius());
		ShapeFactory factory = new ShapeFactory(2,20);
		
		Shape shape;
		//we use Factory method to create objects for different types of Shapes
		//instead of creating directly inside main
		shape = factory.createShape(); //removing the direct dependency on Circle 
		
		//shape = new Circle(); //we do not want main class to directly depend on Circle class
		//so we remove public from Circle class, make the class as default
		
		//shape.setSize(10);
		System.out.println(shape.getArea());
		
		//main class depends on both Shape and Circle
	}

}
