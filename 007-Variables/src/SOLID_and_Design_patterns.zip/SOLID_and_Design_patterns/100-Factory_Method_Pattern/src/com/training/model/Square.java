package com.training.model;

 class Square implements Shape{
	private int size;

	public Square(int size) {
		super();
		this.size = size;
	}

	public Square() {
		super();
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	@Override
	public double getArea() {
		return this.size*this.size;
	}
	
	
}
