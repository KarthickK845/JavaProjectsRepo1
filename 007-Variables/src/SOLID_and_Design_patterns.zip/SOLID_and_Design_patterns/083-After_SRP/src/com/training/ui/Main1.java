package com.training.ui;

import com.training.model.EmailSender;
import com.training.model.SMSSender;
import com.training.model.StoringUserToFile;
import com.training.model.User;
import com.training.model.WhatsAppNotification;

public class Main1 {

	public static void main(String[] args) {
		User user = new User("Mamta", "mamta@gmail.com", "9876759221");
		StoringUserToFile storingUserToFile = new StoringUserToFile();
		storingUserToFile.saveUser(user);
		
		EmailSender emailSender = new EmailSender();
		emailSender.sendEmail(user);
		
		SMSSender smsSender = new SMSSender();
		smsSender.sendSMS(user);
		
		WhatsAppNotification whatsappn = new WhatsAppNotification();
		whatsappn.sendWhatsAppNotification(user);

	}

}
