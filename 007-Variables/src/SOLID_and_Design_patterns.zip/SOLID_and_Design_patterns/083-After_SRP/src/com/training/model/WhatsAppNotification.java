package com.training.model;

public class WhatsAppNotification {
	public void sendWhatsAppNotification(User user) {
		System.out.println("Sending WhatsApp Notification to "+user.getPhoneNumber());
	}
}
