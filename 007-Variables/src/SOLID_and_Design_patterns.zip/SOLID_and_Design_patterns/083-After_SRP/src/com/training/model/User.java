package com.training.model;

public class User {
	//purpose/responsibility of this class is to hold below info only, single responsibility
	private String name;
	private String emailId;
	private String phoneNumber;
	public User(String name, String emailid, String phoneNumber) {
		super();
		this.name = name;
		this.emailId = emailid;
		this.phoneNumber = phoneNumber;
	}
	public User() {
		super();
	}
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
	
}
