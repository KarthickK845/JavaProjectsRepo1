package com.training.model;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class StoringUserToFile {
	
	public void saveUser(User user) {
		OutputStream os;
		try {
			os = new FileOutputStream(user.getName()+".txt");
			Writer writer = new OutputStreamWriter(os);
			writer.write("Name : "+user.getName() +"\n");
			writer.write("Email : "+user.getEmailId()+"\n");
			writer.write("Contact Number : "+user.getPhoneNumber()+"\n");
			
			writer.flush();
			writer.close();
			os.close();
		} catch (Exception e) {
			System.err.println(e);
		}
		
	}
}
