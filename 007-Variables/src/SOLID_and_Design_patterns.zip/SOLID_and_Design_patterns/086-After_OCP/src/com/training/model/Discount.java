package com.training.model;

public interface Discount {
	double calculateDiscount(double amt);
}
