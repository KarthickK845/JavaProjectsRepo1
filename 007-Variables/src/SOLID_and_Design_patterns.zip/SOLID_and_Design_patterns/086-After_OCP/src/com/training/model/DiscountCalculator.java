package com.training.model;

public class DiscountCalculator {
	public double calculateDiscount(Discount discount, double amt) {
		double result = discount.calculateDiscount(amt);
		return result;
	}
}
