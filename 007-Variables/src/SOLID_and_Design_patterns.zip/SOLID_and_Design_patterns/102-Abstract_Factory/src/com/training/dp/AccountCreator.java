package com.training.dp;

public interface AccountCreator {
	Account createAccount(int type);
}
