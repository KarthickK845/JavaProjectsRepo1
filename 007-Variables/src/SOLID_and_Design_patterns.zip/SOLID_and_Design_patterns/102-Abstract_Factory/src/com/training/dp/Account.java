package com.training.dp;

public interface Account {
	void deposit(double amt);
	void withdraw(double amt);
}
