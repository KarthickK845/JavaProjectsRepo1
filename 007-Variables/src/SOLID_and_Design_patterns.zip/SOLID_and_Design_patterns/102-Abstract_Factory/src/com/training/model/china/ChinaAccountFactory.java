package com.training.model.china;

import com.training.dp.Account;
import com.training.dp.AccountCreator;

public class ChinaAccountFactory implements AccountCreator{

	@Override
	public Account createAccount(int type) {
		Account account = null;
		if(type == 1)
			account = new SavingsAccount();
		if(type == 2)
			account = new CurrentAccount();
		if(type == 3)
			account = new FixedDepositAccount();
		return account;
	}
	
}
