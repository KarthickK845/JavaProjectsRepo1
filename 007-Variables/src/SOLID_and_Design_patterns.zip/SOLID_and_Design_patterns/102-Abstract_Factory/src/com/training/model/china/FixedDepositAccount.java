package com.training.model.china;

import com.training.dp.Account;

class FixedDepositAccount implements Account{
	double balance;

	FixedDepositAccount(double balance) {
		super();
		this.balance = balance;
	}

	FixedDepositAccount() {
		super();
	}

	@Override
	public void deposit(double amt) {
		System.out.println("Fixed Deposit Account : Depositing Yuan$."+amt);
		balance+=amt;
	}

	@Override
	public void withdraw(double amt) {
		System.out.println("Fixed Deposit Account : Withdrawing Yuan$."+amt);
		balance-=amt;
	}

	@Override
	public String toString() {
		return "FixedDepositAccount [balance Yuan$=" + balance + "]";
	}
}
