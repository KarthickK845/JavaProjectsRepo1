package com.training.ui;

import com.training.dp.Account;
import com.training.dp.AccountCreator;
import com.training.dp.ConcreteCountryAccountCreator;
import com.training.dp.CountryAccountCreator;

public class Main1 {
	public static void main(String[] args) {
		CountryAccountCreator countryAccountCreator ;  //An abstract factory
		countryAccountCreator = new ConcreteCountryAccountCreator();
		
		AccountCreator accountCreator = countryAccountCreator.create("India");
		Account account = accountCreator.createAccount(1);
		account.deposit(500.00);
		account.withdraw(200.00);
		System.out.println(account);
		System.out.println("------  --------- ---------- ------- ------ ----");
		Account account1 = accountCreator.createAccount(2);
		account1.deposit(700.00);
		account1.withdraw(300.00);
		System.out.println(account1);
		System.out.println("------  --------- ---------- ------- ------ ----");
		Account account2 = accountCreator.createAccount(3);
		account2.deposit(4000.00);
		account2.withdraw(2000.00);
		System.out.println(account2);
		
		System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-");
		
		AccountCreator usaAccountCreator = countryAccountCreator.create("USA");
		Account usaAccount = usaAccountCreator.createAccount(1);
		usaAccount.deposit(15000.00);
		usaAccount.withdraw(2500.00);
		
		System.out.println(usaAccount);
		System.out.println("------  --------- ---------- ------- ------ ----");
		Account usaAccount1 = usaAccountCreator.createAccount(2);
		usaAccount1.deposit(45000.00);
		usaAccount1.withdraw(4500.00);
		
		System.out.println(usaAccount1);
		System.out.println("------  --------- ---------- ------- ------ ----");
		Account usaAccount2 = usaAccountCreator.createAccount(3);
		usaAccount2.deposit(45000.00);
		usaAccount2.withdraw(4500.00);
		
		System.out.println(usaAccount2);
		System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-");
		AccountCreator ukAccountCreator = countryAccountCreator.create("uk");
		Account ukaccount1 = ukAccountCreator.createAccount(1);
		ukaccount1.deposit(3200.00);
		ukaccount1.withdraw(200.00);
		System.out.println(ukaccount1);
		System.out.println("------  --------- ---------- ------- ------ ----");
		Account ukaccount2 = ukAccountCreator.createAccount(2);
		ukaccount2.deposit(7500.00);
		ukaccount2.withdraw(200.00);
		System.out.println(ukaccount2);
		System.out.println("------  --------- ---------- ------- ------ ----");
		Account ukaccount3 = ukAccountCreator.createAccount(3);
		ukaccount3.deposit(10000.00);
		ukaccount3.withdraw(400.00);
		System.out.println(ukaccount3);
		System.out.println("-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-");
		AccountCreator chinaAccountCreator = countryAccountCreator.create("China");
		Account chinaAccount1 = chinaAccountCreator.createAccount(1);
		chinaAccount1.deposit(1060.00);
		chinaAccount1.withdraw(160.00);
		System.out.println(chinaAccount1);
		System.out.println("------  --------- ---------- ------- ------ ----");
		Account chinaAccount2 = chinaAccountCreator.createAccount(2);
		chinaAccount2.deposit(1230.00);
		chinaAccount2.withdraw(230.00);
		System.out.println(chinaAccount2);
		System.out.println("------  --------- ---------- ------- ------ ----");
		Account chinaAccount3 = chinaAccountCreator.createAccount(3);
		chinaAccount3.deposit(16600.00);
		chinaAccount3.withdraw(6000.00);
		System.out.println(chinaAccount3);
		
		
	}
}
