package com.training.model.china;

import com.training.dp.Account;

class CurrentAccount implements Account{

	double balance;

	CurrentAccount(double balance) {
		super();
		this.balance = balance;
	}

	CurrentAccount() {
		super();
	}

	@Override
	public void deposit(double amt) {
		System.out.println("Current Account : Depositing Yuan$."+amt);
		balance+=amt;
	}

	@Override
	public void withdraw(double amt) {
		System.out.println("Current Account : Withdrawing Yuan$."+amt);
		balance-=amt;
	}

	@Override
	public String toString() {
		return "CurrentAccount [balance Yuan$=" + balance + "]";
	}
	
}
