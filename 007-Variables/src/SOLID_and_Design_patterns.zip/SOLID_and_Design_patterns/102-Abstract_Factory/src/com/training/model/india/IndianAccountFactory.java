package com.training.model.india;

import com.training.dp.Account;
import com.training.dp.AccountCreator;

public class IndianAccountFactory implements AccountCreator{

	@Override
	public Account createAccount(int type) {
		Account account = null;
		if(type == 1)
			account = new SavingsAccount();
		if(type == 2)
			account = new CurrentAccount();
		if(type == 3)
			account = new FixedDepositAccount();
		return account;
	}

}
