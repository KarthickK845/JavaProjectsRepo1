package com.training.model.india;

import com.training.dp.Account;

class SavingsAccount implements Account{
	double balance;

	SavingsAccount(double balance) {
		super();
		this.balance = balance;
	}

	SavingsAccount() {
		super();
	}

	@Override
	public void deposit(double amt) {
		System.out.println("Savings Account : Depositing Rs."+amt);
		balance+=amt;
	}

	@Override
	public void withdraw(double amt) {
		System.out.println("Savings Account : Withdrawing Rs."+amt);
		balance-=amt;
	}

	@Override
	public String toString() {
		return "SavingsAccount [balance Rs.=" + balance + "]";
	}

	
}
