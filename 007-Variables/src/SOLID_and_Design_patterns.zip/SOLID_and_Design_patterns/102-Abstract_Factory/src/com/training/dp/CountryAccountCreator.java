package com.training.dp;

public interface CountryAccountCreator {
	AccountCreator create(String country);
}
