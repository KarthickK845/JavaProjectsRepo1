package com.training.model;

public interface Shape {
	int getArea();
}
