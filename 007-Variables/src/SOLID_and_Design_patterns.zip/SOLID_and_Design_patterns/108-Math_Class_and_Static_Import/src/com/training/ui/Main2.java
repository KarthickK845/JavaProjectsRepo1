package com.training.ui;

import java.util.Random;
import static java.lang.Math.cbrt;
import static java.lang.Math.min;
import static java.lang.Math.random;

public class Main2 {
	public static void main(String[] args) {
		//Math is an class with private constructor
		//new Math(); //we can't create object for Math here
		double result1 = min(24.0, 44.0);
		System.out.println(result1);
		
		double result2 = Math.max(24.0, 44.0);
		System.out.println(result2);
		
		System.out.println(cbrt(16.00));  //cube root
		System.out.println(random());
		System.out.println(random()*10);  //generates within 10
		System.out.println((int) (Math.random()*10)); //generates int
		
		Random random = new Random();
		System.out.println(random.nextInt()); //any random +ve or -ve value
		System.out.println(random.nextInt(100)); //random int <100
	}
}
