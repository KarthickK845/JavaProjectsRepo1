package com.training.ui;

import static java.lang.Integer.parseInt;   //this is static import
											//static method is imported to our class
		//we can use static import when we need to use many such static members of other class
import static java.lang.Integer.MIN_VALUE;
import static java.lang.Integer.MAX_VALUE;

public class Main1 {
	public static void main(String[] args) {
		parseInt("123");  //we can just call like this
		System.out.println(MAX_VALUE);   //since these are static and we already did import, we directly access, skipping the class name
		System.out.println(MIN_VALUE);
		
		//from JDK 1.5, Static imports are introduced
	}
}
