package com.training.ui;

import com.training.model.DiscountCalculator;

public class Main1 {

	public static void main(String[] args) {
		DiscountCalculator calculator = new DiscountCalculator();
		double discountForRegular = calculator.calculateDiscount("Regular", 100);
		double discountForPremium = calculator.calculateDiscount("Premium", 100);
		double discountForPlatinum = calculator.calculateDiscount("Platinum", 100);
		
		System.out.println(discountForRegular);
		System.out.println(discountForPremium);
		System.out.println(discountForPlatinum);

	}

}
