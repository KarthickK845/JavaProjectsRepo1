package com.training.ui;

import com.training.model.Calculator;
import com.training.model.MessageCalculator;
import com.training.model.NegativeNumbersCheckingCalculator;
import com.training.model.SimpleCalculator;

public class Main2 {

	public static void main(String[] args) {
		Calculator calculator = new SimpleCalculator(null);
		
		//We can invoke any of the required classes objects or skip or even change the order of the objects
		
		//MessageCalculator mc = new MessageCalculator(calculator);
		NegativeNumbersCheckingCalculator nc = new NegativeNumbersCheckingCalculator(calculator);
		
		
		System.out.println(nc.add(10, -5));
	}

}
