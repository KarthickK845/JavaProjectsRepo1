package com.training.model;

public class SimpleCalculator implements Calculator{
	Calculator calculator;
	
	public SimpleCalculator(Calculator calculator) {
		super();
		this.calculator = calculator;
	}

	public int add(int a, int b) {
		if(this.calculator == null)
			return a+b;
		else {
			this.calculator.add(a, b); //execute the Calculator's add method which is inside that object first and then execute the code here
			int r = a+b;
			return r;
		}
	}
}
