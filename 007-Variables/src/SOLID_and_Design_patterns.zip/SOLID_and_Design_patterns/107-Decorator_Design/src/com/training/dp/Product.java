package com.training.dp;

public interface Product {
	double getPrice();
	double getDiscount();
}
