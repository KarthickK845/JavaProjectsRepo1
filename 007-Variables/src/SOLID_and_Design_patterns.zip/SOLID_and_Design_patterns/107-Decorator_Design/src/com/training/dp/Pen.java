package com.training.dp;

public class Pen implements Product{ //Pen IS A Product
	
	Product product;  //Pen HAS A Product	

	public Pen(Product product) {
	super();
	this.product = product;
}

	@Override
	public double getPrice() {
		if(this.product == null)
			return 100;
		else
			return 100+this.product.getPrice();
	}

	@Override
	public double getDiscount() {
		if(this.product == null)
			return 10;
		else
			return 10+this.product.getDiscount();
	}
	
}
