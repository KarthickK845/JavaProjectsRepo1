package com.training.model;

public interface Calculator {
	int add(int a, int b);
}
