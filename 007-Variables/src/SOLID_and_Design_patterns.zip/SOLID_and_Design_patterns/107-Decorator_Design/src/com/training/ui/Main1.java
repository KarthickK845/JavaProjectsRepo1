package com.training.ui;

import com.training.dp.Box;
import com.training.dp.GiftPack;
import com.training.dp.Pen;

public class Main1 {

	public static void main(String[] args) {
		Pen pen = new Pen(null);  //Pen doesn't contain any Product, so its null
		Box box = new Box(pen);
		GiftPack giftPack = new GiftPack(box);
		
		System.out.println(giftPack.getPrice()); //prints price including pen's price
		System.out.println(giftPack.getDiscount());
	}

}
