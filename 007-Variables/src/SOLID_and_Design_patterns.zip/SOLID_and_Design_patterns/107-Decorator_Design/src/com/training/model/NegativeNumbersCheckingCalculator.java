package com.training.model;

public class NegativeNumbersCheckingCalculator implements Calculator{
	//This is a Decorator Class
	//This class takes care of Negative Numbers
	
	Calculator calculator;

	public NegativeNumbersCheckingCalculator(Calculator calculator) {
		super();
		this.calculator = calculator;
	}

	@Override
	public int add(int a, int b) {
		if(this.calculator==null) {
			return 0;
		}
		else {
			if(a<0 || b<0) {
				System.out.println("Negative Numbers found ");
				return 0;
			}else {
				//We are giving additional code here without affecting the SimpleCalculator class
				//System.out.println("Welcome"); //We can give this logic in different decorator class also
				//like we give in MessageCalculator class
				int r=this.calculator.add(a, b);
				//System.out.println("Thanks");
				return r;
			}
		}
	}
	
	
}
