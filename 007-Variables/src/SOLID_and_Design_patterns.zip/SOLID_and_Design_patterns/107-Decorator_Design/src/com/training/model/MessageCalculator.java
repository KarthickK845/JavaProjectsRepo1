package com.training.model;

public class MessageCalculator implements Calculator{
	
	//This class takes care of printing the message before and after addition method call
	
	//MessageCalculator must have both IS A and HAS A relation with Calculator
	Calculator calculator;

	
	
	public MessageCalculator(Calculator calculator) {
		super();
		this.calculator = calculator;
	}



	@Override
	public int add(int a, int b) {
		if(this.calculator==null) {
			return 0;
		}else {
			System.out.println("Welcome");
			int r = this.calculator.add(a, b);
			System.out.println("Thank you.");
			return r;
		}
	}  
	
	
}
