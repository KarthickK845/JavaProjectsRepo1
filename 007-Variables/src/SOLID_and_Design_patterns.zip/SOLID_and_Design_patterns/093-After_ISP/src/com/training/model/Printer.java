package com.training.model;

public interface Printer {
	void printDocument();
}
