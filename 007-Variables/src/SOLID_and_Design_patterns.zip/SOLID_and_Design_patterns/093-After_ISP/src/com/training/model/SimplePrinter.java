package com.training.model;

public class SimplePrinter implements Printer{

	@Override
	public void printDocument() {
		System.out.println("Printing the document");
	}

}
