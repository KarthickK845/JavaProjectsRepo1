package com.training.model;

public interface Scanner {
	void scanDocument();
}
