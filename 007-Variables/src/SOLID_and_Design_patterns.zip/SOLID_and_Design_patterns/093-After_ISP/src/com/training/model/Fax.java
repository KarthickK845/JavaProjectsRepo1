package com.training.model;

public interface Fax {
	void faxDocument();
}
