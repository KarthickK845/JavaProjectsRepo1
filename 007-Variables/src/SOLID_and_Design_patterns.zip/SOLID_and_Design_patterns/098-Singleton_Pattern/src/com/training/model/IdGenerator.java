package com.training.model;

public class IdGenerator {
	//purpose is to generate ID for any type say Student, Employee, ..
	private int number=0;
	
	public int getNextId() {
		return ++number;
	}
	
	//Steps to achieve Singleton Pattern
	//Step 1
	private IdGenerator() {
		
	}
	
	//Step 2
	private static IdGenerator instance = null;
	
	//Step 3
	public static IdGenerator getInstance() {
		if(instance == null)
			instance = new IdGenerator(); //only once object is created
		return instance; 
	}
}
