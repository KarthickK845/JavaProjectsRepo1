package com.training.ui;

import com.training.model.IdGenerator;

public class Main {

	public static void main(String[] args) {
		IdGenerator generator = IdGenerator.getInstance();
		System.out.println(generator.getNextId());
		System.out.println(generator.getNextId());
		System.out.println(generator.getNextId());
		System.out.println(generator.getNextId());
		
		IdGenerator generator1 = IdGenerator.getInstance();
		System.out.println(generator1.getNextId());
		System.out.println(generator1.getNextId());
		System.out.println(generator1.getNextId());
		System.out.println(generator1.getNextId());
	
		IdGenerator generator2 = IdGenerator.getInstance();
		System.out.println(generator2.getNextId());
		System.out.println(generator2.getNextId());
		System.out.println(generator2.getNextId());
		System.out.println(generator2.getNextId());
	
		IdGenerator generator3 = IdGenerator.getInstance();
		System.out.println(generator3.getNextId());
	}

}
