package com.training.dp;

public interface Observer {
	void update(String news);
}
