package com.training.ui;

import com.training.dp.NewsPaper;
import com.training.dp.NewsStation;
import com.training.dp.Observer;
import com.training.dp.TVChannel;
import com.training.dp.Youtube;

public class Main {

	public static void main(String[] args) {
		Observer observer1 = new NewsPaper();
		Observer observer2 = new TVChannel();
		Observer observer3 = new Youtube();
		
		NewsStation subject = new NewsStation();
		
		subject.addObserver(observer1);
		subject.addObserver(observer2);
		
		System.out.println("----- 6.00 AM NEWS -----");
		subject.setNews("Elections 2025 : BCD Party likely to win the Parlimentary elections");
		
		subject.addObserver(observer3);
		System.out.println("----- 5.00 PM NEWS -----");
		subject.setNews("Elections 2025 : XYZ Party gets defeated by 10000 votes");
		
		subject.removeObserver(observer1);
		System.out.println("----- 7.00 PM NEWS -----");
		subject.setNews("Breaking News : ABC becomes the NEW PRIME MINISTER of India");
	}

}
