package com.training.ui;

import com.training.model.Rectangle;
import com.training.model.Square;

public class Main {

	public static void main(String[] args) {
		Rectangle rectangle = new Rectangle();
		rectangle.setHeight(10);
		rectangle.setWidth(5);
		System.out.println(rectangle.getArea());
		
		Square square = new Square();
		square.setWidth(10);
		System.out.println(square.getArea());
		
		//this will not useful, when we have different Shapes with different fields other than width, height of Rectangle
	}

}
