package com.training.model;

public class LightBulb implements Switchable{
	public void turnOn() {
		System.out.println("Light On");
	}
	
	public void turnOff() {
		System.out.println("Light Off");
	}
}
