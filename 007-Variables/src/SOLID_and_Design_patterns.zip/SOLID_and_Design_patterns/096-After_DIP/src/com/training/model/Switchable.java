package com.training.model;

public interface Switchable {
	void turnOn();
	void turnOff();
}
