package com.training.model;

public class Switch {
	Switchable switchable; //a common module for LightBulb, Radio, TV
	
	public Switch(Switchable switchable) {
		this.switchable=switchable;
	}

	public void turnOn() {
		this.switchable.turnOn();
	}
	
	public void turnOff() {
		this.switchable.turnOff();
	}
}
