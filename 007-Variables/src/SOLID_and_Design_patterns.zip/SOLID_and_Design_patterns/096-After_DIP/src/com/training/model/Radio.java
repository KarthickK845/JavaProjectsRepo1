package com.training.model;

public class Radio implements Switchable{
	public void turnOn() {
		System.out.println("Radio On");
	}
	
	public void turnOff() {
		System.out.println("Radio Off");
	}
}
