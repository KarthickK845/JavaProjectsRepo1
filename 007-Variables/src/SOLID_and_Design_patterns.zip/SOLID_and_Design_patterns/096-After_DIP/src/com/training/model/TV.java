package com.training.model;

public class TV implements Switchable
{

	@Override
	public void turnOn() {
		System.out.println("TV is On");
	}

	@Override
	public void turnOff() {
		System.out.println("TV is Off");
	}
	
}
