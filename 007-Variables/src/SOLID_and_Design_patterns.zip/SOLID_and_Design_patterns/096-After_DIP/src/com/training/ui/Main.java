package com.training.ui;

import com.training.model.Radio;
import com.training.model.Switch;
import com.training.model.Switchable;
import com.training.model.TV;

public class Main {
	public static void main(String[] args) {
		//LightBulb bulb = new LightBulb();
		Switchable switchable = new Radio();
		Switch switch1 = new Switch(switchable);
		
		//We are doing loose-coupling here using DIP Dependency Inversion Principle
		
		switch1.turnOn();
		switch1.turnOff();
	}
}
