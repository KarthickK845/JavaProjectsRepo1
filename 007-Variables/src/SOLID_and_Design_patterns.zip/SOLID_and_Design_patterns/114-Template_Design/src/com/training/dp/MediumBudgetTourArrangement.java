package com.training.dp;

public class MediumBudgetTourArrangement extends TourArrangement{

	@Override
	public double bookHotel(int personCount) {
		System.out.println("Because of Medium Budget, booking 3 star hotel");
		double cost = 2000.00;
		return cost*personCount;
	}

	@Override
	public double arrangeTransport(int personCount) {
		System.out.println("Because of Medium Budget, arranging cab for transport");
		double cost = 3000.00;
		return cost*personCount;
	}

	@Override
	public double arrangeFood(int personCount) {
		System.out.println("Because of Medium Budget, arranging Veg and Egg based food");
		double cost = 700.00;
		return cost*personCount;
	}

}
