package com.training.dp;

public abstract class TourArrangement {
	//Template Design Pattern
	//structure is combo of 1 final method and few abstract methods
	
	public final double arrangeTour(int personCount) { //cannot be overridden
		//same logic and order of steps will be followed for any type of Tour arrangement
		
		double cost = bookHotel(personCount);
		cost = cost + arrangeTransport(personCount);
		cost = cost + arrangeFood(personCount);
		return cost;
	}
	
	//implementation of these below methods are done in the subclasses
	public abstract double bookHotel(int personCount); 
	public abstract double arrangeTransport(int personCount);
	public abstract double arrangeFood(int personCount);
	
}
