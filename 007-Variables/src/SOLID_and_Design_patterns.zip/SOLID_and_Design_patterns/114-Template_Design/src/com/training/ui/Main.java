package com.training.ui;

import com.training.dp.LowBudgetTourArrangement;
import com.training.dp.MediumBudgetTourArrangement;
import com.training.dp.RichBudgetTourArrangement;
import com.training.dp.TourArrangement;

public class Main {
	public static void main(String[] args) {
		TourArrangement arrangement = new RichBudgetTourArrangement();
		double totalCost = arrangement.arrangeTour(10);
		System.out.println(totalCost);
		
		arrangement = new MediumBudgetTourArrangement();
		double totalCost2 = arrangement.arrangeTour(10);
		System.out.println(totalCost2);
		
		arrangement = new LowBudgetTourArrangement();
		double totalCost1 = arrangement.arrangeTour(10);
		System.out.println(totalCost1);
		
		System.out.println(Long.MAX_VALUE);
		Long.parseLong("355687428096000");
	}
}
