package com.training.model;

public class Switch {
	//Switch is high level module, dependent on LighBulb
	
	LightBulb lightBulb; //LightBulb is a low level module
	//unable to use Radio module here as both this and LightBulb are low level modules
	//and use same methods, but Switch can turn on LightBulb only and cannot turnOn Radio
	
	public Switch(LightBulb bulb) {
		this.lightBulb=bulb;
	}

	public void turnOn() {
		this.lightBulb.turnOn();
	}
	
	public void turnOff() {
		this.lightBulb.turnOff();
	}
}
