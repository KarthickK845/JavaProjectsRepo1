package com.training.ui;

import com.training.model.LightBulb;
import com.training.model.Switch;

public class Main {
	public static void main(String[] args) {
		LightBulb bulb = new LightBulb();
		Switch switch1 = new Switch(bulb);
		
		switch1.turnOn();
		switch1.turnOff();
	}
}
