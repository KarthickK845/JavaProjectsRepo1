package com.training.model;

public interface GradeWiseSalaryCalculator {
	double calculateSalary(double basic);
}
