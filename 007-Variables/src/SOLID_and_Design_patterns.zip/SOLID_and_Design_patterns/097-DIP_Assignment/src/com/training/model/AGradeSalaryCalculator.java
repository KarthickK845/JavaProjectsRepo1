package com.training.model;

public class AGradeSalaryCalculator implements GradeWiseSalaryCalculator{

	@Override
	public double calculateSalary(double basic) {
		return basic*0.35;
	}
	
}
