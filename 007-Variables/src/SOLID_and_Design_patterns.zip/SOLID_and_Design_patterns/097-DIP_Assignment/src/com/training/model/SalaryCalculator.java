package com.training.model;

public class SalaryCalculator {
	GradeWiseSalaryCalculator gradeWiseSalaryCalculator;

	public SalaryCalculator(GradeWiseSalaryCalculator gradeWiseSalaryCalculator) {
		this.gradeWiseSalaryCalculator = gradeWiseSalaryCalculator;
	}
	
	public void printSalary(double basic) {
		System.out.println(this.gradeWiseSalaryCalculator.calculateSalary(basic));
	}
}
