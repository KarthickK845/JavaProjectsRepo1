package com.training.ui;

import com.training.model.AGradeSalaryCalculator;
import com.training.model.BGradeSalaryCalculator;
import com.training.model.CGradeSalaryCalculator;
import com.training.model.GradeWiseSalaryCalculator;
import com.training.model.SalaryCalculator;

public class Main {
	public static void main(String[] args) {
		GradeWiseSalaryCalculator gradeWiseSalaryCalculator;
		
		gradeWiseSalaryCalculator = new AGradeSalaryCalculator();
		SalaryCalculator salaryCalculator = new SalaryCalculator(gradeWiseSalaryCalculator);
		System.out.print("A Grade Salary : ");
		salaryCalculator.printSalary(20000.00);

		gradeWiseSalaryCalculator = new BGradeSalaryCalculator();
		salaryCalculator = new SalaryCalculator(gradeWiseSalaryCalculator);
		System.out.print("B Grade Salary : ");
		salaryCalculator.printSalary(20000.00);

		gradeWiseSalaryCalculator = new CGradeSalaryCalculator();
		salaryCalculator = new SalaryCalculator(gradeWiseSalaryCalculator);
		System.out.print("C Grade Salary : ");
		salaryCalculator.printSalary(20000.00);

	}
}
