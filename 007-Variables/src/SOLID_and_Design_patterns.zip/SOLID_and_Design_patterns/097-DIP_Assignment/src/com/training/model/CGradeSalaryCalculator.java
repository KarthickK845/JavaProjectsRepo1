package com.training.model;

public class CGradeSalaryCalculator implements GradeWiseSalaryCalculator{

	@Override
	public double calculateSalary(double basic) {
		return basic*0.15;
	}
	
}
