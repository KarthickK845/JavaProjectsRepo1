package com.training.dp;

public class UniversityStudent {
	String studentName;
	String studentSurName;
	String studentContact;
	public UniversityStudent(String getStudentName, String getStudentSurName, String getStudentContact) {
		super();
		this.studentName = getStudentName;
		this.studentSurName = getStudentSurName;
		this.studentContact = getStudentContact;
	}
	public UniversityStudent() {
		super();
	}
	
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentSurName() {
		return studentSurName;
	}
	public void setStudentSurName(String studentSurName) {
		this.studentSurName = studentSurName;
	}
	public String getStudentContact() {
		return studentContact;
	}
	public void setStudentContact(String studentContact) {
		this.studentContact = studentContact;
	}
	@Override
	public String toString() {
		return "\nUniversityStudent [getStudentName=" + studentName + ", getStudentSurName=" + studentSurName
				+ ", getStudentContact=" + studentContact + "]";
	}
	
	
}
