package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.dp.CollegeStudent;
import com.training.dp.SchoolStudent;
import com.training.dp.SchoolStudentAdapter;
import com.training.dp.Student;
import com.training.dp.UniversityStudent;
import com.training.dp.UniversityStudentAdapter;

public class Main01 {
	public static void main(String[] args) {
		List<Student> students = new LinkedList<>();
		CollegeStudent cs = new CollegeStudent("Amba","Menon","amba@gmail.com");
		students.add(cs);
		
		SchoolStudent ss = new SchoolStudent("Akshara", "Nair", "akshanair@gmail.com"); //Adaptee
		SchoolStudentAdapter ssa = new SchoolStudentAdapter(ss); //Adapter
		students.add(ssa);
		
		UniversityStudent us = new UniversityStudent("Aruna", "Roy", "arunaroy@gmail.com"); //Adaptee
		UniversityStudentAdapter usa = new UniversityStudentAdapter(us); //Adapter
		students.add(usa);
		System.out.println(students);
		
		
	}
}
