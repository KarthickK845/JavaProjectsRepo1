package com.training.dp;

public interface Student {
	public String getName();
	public String getSurName();
	public String getEmail();
}
