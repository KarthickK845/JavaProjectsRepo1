package com.training.ui;

import com.training.model.RollNumberGenerator;

public class Main {

	public static void main(String[] args) {
		RollNumberGenerator rngenerator = RollNumberGenerator.getInstance();
		System.out.println(rngenerator.getNextRollNumber());
		System.out.println(rngenerator.getNextRollNumber());
		System.out.println(rngenerator.getNextRollNumber());
		System.out.println(rngenerator.getNextRollNumber());
		
		RollNumberGenerator rngenerator1 = RollNumberGenerator.getInstance();
		System.out.println(rngenerator1.getNextRollNumber());
		System.out.println(rngenerator1.getNextRollNumber());
		System.out.println(rngenerator1.getNextRollNumber());
		
		RollNumberGenerator rngenerator2 = RollNumberGenerator.getInstance();
		System.out.println(rngenerator2.getNextRollNumber());
		System.out.println(rngenerator2.getNextRollNumber());

		RollNumberGenerator rngenerator3 = RollNumberGenerator.getInstance();
		System.out.println(rngenerator3.getNextRollNumber());
	}

}
