package com.training.ui;

import com.training.model.Account;
import com.training.model.AccountFactory;

public class Main {

	public static void main(String[] args) {
		AccountFactory accountFactory = new AccountFactory('C', 35000.00);

		Account account = accountFactory.createAccount();
		account.deposit(5050.00);
		account.withdraw(6500.00);
		System.out.println(account);
		
		System.out.println("===========================================");
		
		AccountFactory accountFactory2 = new AccountFactory('S', 15000.00);

		Account account2 = accountFactory2.createAccount();
		account2.deposit(5550.00);
		account2.withdraw(7500.00);
		System.out.println(account2);
		System.out.println("===========================================");
		AccountFactory accountFactory3 = new AccountFactory('F', 25000.00);

		Account account3 = accountFactory3.createAccount();
		account3.deposit(8000.00);
		account3.withdraw(9500.00);
		System.out.println(account3);
	}

}
