package com.training.model;

 class FixedDepositAccount implements Account{
	
	private double balance;

	 FixedDepositAccount(double balance) {
		super();
		this.balance = balance;
	}

	 FixedDepositAccount() {
		super();
	}

	public double getBalance() {
		return balance;
	}

	@Override
	public void setBalance(double balanceAmt) {
		this.balance = balanceAmt;
		System.out.println("FD Account Balance Added : New Balance : "+this.balance);
	}

	@Override
	public void withdraw(double withdrawAmt) {
		this.balance -= withdrawAmt;
		System.out.println("FD Account Withdrawal Done : New Balance : "+this.balance);
	}

	@Override
	public void deposit(double depositAmount) {
		this.balance += depositAmount;
		System.out.println("FD Account Deposit Done : New Balance : "+this.balance);
	}

	@Override
	public String toString() {
		return "FixedDepositAccount [balance=" + balance + "]";
	}
	
	

}
