package com.training.model;

 class SavingsAccount implements Account {

	private double balance;

	 SavingsAccount(double balance) {
		super();
		this.balance = balance;
	}

	 SavingsAccount() {
		super();
	}

	public double getBalance() {
		return balance;
	}

	@Override
	public void setBalance(double balanceAmt) {
		this.balance = balanceAmt;
		System.out.println("Savings Account Balance Added : New Balance : "+this.balance);
	}

	@Override
	public void withdraw(double withdrawAmt) {
		this.balance -= withdrawAmt;
		System.out.println("Savings Account Withdrawal Done : New Balance : "+this.balance);
	}

	@Override
	public void deposit(double depositAmount) {
		this.balance += depositAmount;
		System.out.println("Savings Account Deposit Done : New Balance : "+this.balance);
	}

	@Override
	public String toString() {
		return "SavingsAccount [balance=" + balance + "]";
	}

	
}
