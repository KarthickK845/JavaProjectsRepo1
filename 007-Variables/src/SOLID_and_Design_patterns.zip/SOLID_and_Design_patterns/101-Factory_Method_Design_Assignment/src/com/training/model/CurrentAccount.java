package com.training.model;

 class CurrentAccount implements Account {

	private double balance;

	 CurrentAccount(double balance) {
		super();
		this.balance = balance;
	}

	 CurrentAccount() {
		super();
	}

	public double getBalance() {
		return balance;
	}

	@Override
	public void setBalance(double balanceAmt) {
		this.balance = balanceAmt;
		System.out.println("Current Account Balance Added : New Balance : "+this.balance);
	}

	@Override
	public void withdraw(double withdrawAmt) {
		this.balance -= withdrawAmt;
		System.out.println("Current Account Withdrawal Done : New Balance : "+this.balance);
	}

	@Override
	public void deposit(double depositAmount) {
		this.balance += depositAmount;
		System.out.println("Current Account Deposit Done : New Balance : "+this.balance);
	}

	@Override
	public String toString() {
		return "CurrentAccount [balance=" + balance + "]";
	}

	
}
