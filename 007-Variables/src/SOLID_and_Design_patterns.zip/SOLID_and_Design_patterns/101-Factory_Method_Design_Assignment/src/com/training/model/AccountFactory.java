package com.training.model;

public class AccountFactory {
	char accType;
	double balance;
	
	public AccountFactory(char type, double balance) {
		super();
		this.accType = type;
		this.balance = balance;
	}
	
	public AccountFactory() {
		super();
	}

	public Account createAccount() {
		Account account = null;
		if(accType == 'C')
			account = new CurrentAccount();
		if(accType == 'S')
			account = new SavingsAccount();
		if(accType == 'F')
			account = new FixedDepositAccount();
		
		account.setBalance(balance);
		
		return account;
	}
}
