package com.training.dp;

public class FolderIcon implements Icon{
	private String color; //Intrinsic state: color of the folder icon
	private String imageName;  //Intrinsic state: image name of the folder icon
	public FolderIcon(String color, String imageName) {
		super();
		this.color = color;
		this.imageName = imageName;
	}
	@Override
	public void draw(int x, int y) {
		System.out.println("Drawing folder icon with color "+color+" and image "+imageName+" at position ("+ x+", "+y+")");
	}
	
	
}
