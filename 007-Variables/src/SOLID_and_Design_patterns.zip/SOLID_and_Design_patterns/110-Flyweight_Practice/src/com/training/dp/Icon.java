package com.training.dp;

public interface Icon {
	void draw(int x, int y);
}
