package com.training.dp;

public interface Shape {
	void setSize(double size);
	double getArea();
}
