package com.training.dp;

public class CircleAdapter implements Shape{
	Circle c;

	public CircleAdapter(Circle c) {
		super();
		this.c = c;
	}

	@Override
	public void setSize(double size) {
		c.setRadius(size);
	}

	@Override
	public double getArea() {
		return c.computeArea();
	}

	@Override
	public String toString() {
		return "\nCircleAdapter [c=" + c + "]";
	}

	
	
	
	
}
