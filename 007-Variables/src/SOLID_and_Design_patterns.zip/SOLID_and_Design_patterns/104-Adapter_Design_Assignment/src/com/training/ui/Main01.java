package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.dp.Circle;
import com.training.dp.CircleAdapter;
import com.training.dp.Shape;
import com.training.dp.Square;
import com.training.dp.SquareAdapter;

public class Main01 {

	public static void main(String[] args) {
		List<Shape> shapes = new LinkedList<>();
		
		Circle c = new Circle(15);
		CircleAdapter ca = new CircleAdapter(c);
		shapes.add(ca);
		
		Square s = new Square(25);
		SquareAdapter sa = new SquareAdapter(s);
		shapes.add(sa);
		
		Circle c1 = new Circle(10);
		CircleAdapter ca1 = new CircleAdapter(c1);
		shapes.add(ca1);
		
		Square s1 = new Square(20);
		SquareAdapter sa1 = new SquareAdapter(s1);
		shapes.add(sa1);
		
		System.out.println(shapes);
	}

}
