package com.training.dp;

public class SquareAdapter implements Shape{
	
	Square s;

	public SquareAdapter(Square s) {
		super();
		this.s = s;
	}

	@Override
	public void setSize(double size) {
		s.setSize(size);
	}

	@Override
	public double getArea() {
		return s.computeArea();
	}

	@Override
	public String toString() {
		return "\nSquareAdapter [s=" + s + "]";
	}
	
	
}
