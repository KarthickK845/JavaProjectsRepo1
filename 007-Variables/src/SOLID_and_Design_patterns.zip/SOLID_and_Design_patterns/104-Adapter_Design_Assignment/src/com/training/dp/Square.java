package com.training.dp;

public class Square {
	private double size;

	public Square(double size) {
		super();
		this.size = size;
	}

	public double getSize() {
		return size;
	}

	public void setSize(double size) {
		this.size = size;
	}
	
	public double computeArea() {
		return this.size*this.size;
	}

	@Override
	public String toString() {
		return "Square [size=" + size + ", computeArea()=" + computeArea() + "]";
	}

	
	
	
}
