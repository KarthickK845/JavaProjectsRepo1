package com.training.dp;

public class TourArrangementFacade {
	public void arrangeTour(int numberOfPersons, int numberOfDays) {
		HotelBooking hotelBooking = new HotelBooking();
		TravelArrangements trarr = new TravelArrangements();
		FoodArrangement foodarr = new FoodArrangement();
		
		boolean isRoomAvailable = hotelBooking.roomsAvailable(numberOfPersons);
		
		System.out.println("Rooms Available : "+isRoomAvailable);
		
		if(isRoomAvailable) {
			System.out.println(hotelBooking.bookRooms(numberOfPersons, numberOfDays));
			System.out.println("Amount Charged : "+hotelBooking.chargeForBooking());
			trarr.arrange(numberOfPersons);			
			System.out.println(foodarr.arrangeFood(numberOfPersons));
		}
	}

}
