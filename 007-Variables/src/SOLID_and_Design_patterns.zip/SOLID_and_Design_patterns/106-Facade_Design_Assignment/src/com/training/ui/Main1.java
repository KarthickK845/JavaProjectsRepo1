package com.training.ui;

import com.training.dp.FoodArrangement;
import com.training.dp.HotelBooking;
import com.training.dp.TravelArrangements;

public class Main1 {

	public static void main(String[] args) {
		// code for arranging the tour without facade
		System.out.println("--- Without Facade ---");
		
		HotelBooking hb = new HotelBooking();
		boolean isRoomAvailable = hb.roomsAvailable(30);
		System.out.println("Rooms Available : " + isRoomAvailable);

		if (isRoomAvailable) {
			System.out.println(hb.bookRooms(30, 20));
			System.out.println("Amount Charged : " + hb.chargeForBooking());

			TravelArrangements trarr = new TravelArrangements();
			trarr.arrange(30);

			FoodArrangement foodarr = new FoodArrangement();
			foodarr.arrangeFood(30);
		}

	}

}
