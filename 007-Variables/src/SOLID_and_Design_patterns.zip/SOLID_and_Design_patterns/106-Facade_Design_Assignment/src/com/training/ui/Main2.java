package com.training.ui;

import com.training.dp.TourArrangementFacade;

public class Main2 {

	public static void main(String[] args) {
		// with Facade
		System.out.println("--- With Facade ---");
		
		TourArrangementFacade hbf = new TourArrangementFacade();
		hbf.arrangeTour(30,20);
	}

}
