package com.training.dp;

public class TravelArrangements {
	public void arrange(int numberOfPersons) {
		System.out.println("Travel Cost : Rs.3000/person");
		System.out.println(numberOfPersons*3000 + " Charged");
	}
}
