package com.training.ui;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

class Graph<T> {
	private Map<T, List<T>> map = new TreeMap<>();
	
	public void addVertex(T s) {
		map.put(s, new LinkedList<>());
	}
	
	public void addEdge(T source, T destination, boolean bidirectional) {
		if(! map.containsKey(source))
			addVertex(source);
		
		if(! map.containsKey(destination))
			addVertex(destination);
		
		map.get(source).add(destination);
		if(bidirectional)
			map.get(destination).add(source);
	}
	
	public String toString() {
		StringBuilder builder = new StringBuilder();
		
		for(T v : map.keySet()) {
			builder.append(v.toString()+" : ");
			
			for(T w : map.get(v)) {
				builder.append(w.toString() + " ");
			}
			
			builder.append("\n");
		}
		
		return builder.toString();
	}
}

public class Main {
	
	static int[][] solve(int M, int N, int[][] a, int q, int[] queries){
		Graph<Integer> graph = new Graph<>();
		
		for(int i=0;i<a.length;i++) {
			graph.addEdge(a[i][0], a[i][1], true);
		}
		
		System.out.println(graph);
		return null;
	}

	public static void main(String[] args) {
		int N=5;
		int M=4;
		int[][] a= {{1,4},{1,3},{1,2},{1,4}};
		int q = 5;
		int[] queries = {1,2,3,4,5};
		
		int[][] result = solve(N,M,a,q,queries);
		
	}

}
