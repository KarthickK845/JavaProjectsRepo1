package com.training.model;

public class Teacher {
	String name;
	String subjectName;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	@Override
	public String toString() {
		return "Teacher [name=" + name + ", subjectName=" + subjectName + "]";
	}
	
	
}
