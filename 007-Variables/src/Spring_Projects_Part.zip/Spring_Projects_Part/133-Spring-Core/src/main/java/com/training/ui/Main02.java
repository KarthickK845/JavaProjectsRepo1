package com.training.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.HelloWorld;

public class Main02 {
	public static void main(String[] args) {
		HelloWorld helloWorld;
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		helloWorld = (HelloWorld) context.getBean("helloWorldBean");
		helloWorld.setMessage("Welcome to Spring Class");
		System.out.println(helloWorld.getMessage());
	}
}
