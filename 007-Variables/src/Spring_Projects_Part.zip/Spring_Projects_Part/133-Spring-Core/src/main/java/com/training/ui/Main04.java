package com.training.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.Student;

public class Main04 {

	public static void main(String[] args) {
		//3 references of Student
		Student student1;
		Student student2;
		Student student3;
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		//initialize
		student1 = (Student) context.getBean("studentBean");
		student2 = (Student) context.getBean("studentBean");
		student3 = (Student) context.getBean("studentBean");
		
		//set RollNumber
		student1.setRollNumber(101);
		student2.setRollNumber(102);
		student3.setRollNumber(103);
		
		//print
		System.out.println(student1);
		System.out.println(student2);
		System.out.println(student3);

	}

}
