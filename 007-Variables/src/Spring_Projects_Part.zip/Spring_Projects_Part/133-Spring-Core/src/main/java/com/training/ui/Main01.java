package com.training.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.model.Shape;

public class Main01 {

	public static void main(String[] args) {
		Shape shape;
		
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("beans.xml");
		
		//making this a loosely couple application by fetching only the required Bean 
		//thru beans.xml, working like a factory
		//modifying only bean name without much modifications to code
		shape=(Shape) context.getBean("rectangleBean");
		shape.setSize(10);
		System.out.println(shape.getArea());
		System.out.println(shape.toString());
	}

}
