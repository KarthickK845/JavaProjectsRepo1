package com.training.model;

public class Contact {
	String emailId;
	String phone;
	public Contact(String emailId, String phone) {
		super();
		this.emailId = emailId;
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Contact [emailId=" + emailId + ", phone=" + phone + "]";
	}
	
	
	
}
