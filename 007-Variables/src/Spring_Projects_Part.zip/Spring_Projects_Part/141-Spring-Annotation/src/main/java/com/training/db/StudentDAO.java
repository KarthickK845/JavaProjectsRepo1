package com.training.db;

import org.springframework.stereotype.Repository;

@Repository    //DB layer
public class StudentDAO {

	@Override
	public String toString() {
		return "StudentDAO []";
	}
	
}
