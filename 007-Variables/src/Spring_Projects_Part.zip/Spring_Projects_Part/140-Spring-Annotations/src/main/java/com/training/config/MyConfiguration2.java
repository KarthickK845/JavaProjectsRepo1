package com.training.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.training.model.Address;
import com.training.model.Customer;

@Configuration
public class MyConfiguration2 {
	
	@Bean(name="ChennaiAddress")
	public Address f3() {
		Address address = new Address("D-1","Chennai","600028");
		return address;
	}
	
	@Bean
	public Customer f4() {
		Customer customer = new Customer();
		customer.setId(1001);
		customer.setName("Abhinav");
		//customer.setAddress(f3());  //this is equivalent to autowiring by type in beans.xml 
		// - Address type of object is returned by calling f3 method
		return customer;
	}
	
	@Bean(name="CochinAddress")
	public Address f5() {
		Address address = new Address("T3","Cochin","500045");
		return address;
	}
}
