package com.training.model;

public class Address {
	String doorNumber;
	String cityName;
	String pincode;
	public Address(String doorNumber, String cityName, String pincode) {
		super();
		this.doorNumber = doorNumber;
		this.cityName = cityName;
		this.pincode = pincode;
	}
	public Address() {
		super();
	}
	public String getDoorNumber() {
		return doorNumber;
	}
	public void setDoorNumber(String doorNumber) {
		this.doorNumber = doorNumber;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Address [doorNumber=" + doorNumber + ", cityName=" + cityName + ", pincode=" + pincode + "]";
	}
	
	
}
