use trainingdb19;

update employees set name='Meena' where id=104;
update employees set salary=21000 where id=102;
update employees set name='Mihira',salary = 11000 where id=105; 

select * from employees;

delete from employees where id=106;
delete from employees where salary<=10000;

insert into employees values(105,'Abdul',10000.00);

select * from employees order by salary;