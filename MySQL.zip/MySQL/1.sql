use trainingdb19;

create table <<table_name>>
(
	<<col_name1>> datatype;
	<<col_name2>> datatype;
	<<col_name3>> datatype
);