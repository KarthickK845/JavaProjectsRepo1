create table employees(
id 		integer,
name	varchar(50),
salary	double
);

select * from employees;
describe employees;

insert into employees(id,name,salary) values(101,'Ram',15000.00);
insert into employees(id,name,salary) values(102,'Krishna',25000.00);
insert into employees(id,name,salary) values(103,'Murugan',65000.00);
insert into employees(id,name,salary) values(104,'Kandhan',35000.00);
insert into employees values(105,'Abdul',10000.00);
insert into employees(id,name) values(106,'Misha');

select id,name,salary from employees;
select name,salary from employees;
select salary from employees;

select id as "empid",name as "First Name", salary+100 as "Incremented Salary" from employees;

select * from employees where salary>13000;
select * from employees where name = 'Ram';
select * from employees where id = 102;
select * from employees where salary>13000 and salary<27000;
select * from employees where salary between 13000 and 27000;
select * from employees where salary is null;

update employees set name='Meena' where id=104;
update employees set salary=21000 where id=102;