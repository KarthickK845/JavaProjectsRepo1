create database trainingdb19;
create database trainingdb20;
create database trainingdb21;